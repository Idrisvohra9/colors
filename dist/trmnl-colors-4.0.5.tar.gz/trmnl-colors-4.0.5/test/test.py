from trmnl_colors import *
bluebg()
print("Hello")
reset()