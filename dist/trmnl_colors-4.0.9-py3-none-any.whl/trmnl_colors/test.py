print("\033[9;9m",end="")

print("Something")